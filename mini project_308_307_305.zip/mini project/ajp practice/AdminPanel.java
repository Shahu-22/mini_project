import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


class AdminPanel extends JFrame implements ActionListener {
    JMenuBar homeMenu;
    JMenu home, collection, credit;
    JMenuItem newMember, newOrg, newAdmin,morning,evening;

    AdminPanel() {
        this.setLayout(null);
		this.setSize(500,400);
		this.getContentPane().setBackground(Color.red);
  
        homeMenu = new JMenuBar();
		
        //menu home and submenu initialization
		home = new JMenu("Home");
		newMember = new JMenuItem("New Member");
		newOrg = new JMenuItem("New Organization");
		newAdmin = new JMenuItem("New Admin");
        home.add(newMember);
		home.add(newOrg);
		home.add(newAdmin);
		
        collection = new JMenu("Collection");
		 morning=new JMenuItem("Morning");
		 evening=new JMenuItem("Evening");
		collection.add(morning);
		collection.add(evening);
        credit = new JMenu("Credit");

        homeMenu.add(home);
        homeMenu.add(collection);
        homeMenu.add(credit);

       newMember.addActionListener(this);
	   newOrg.addActionListener(this);
	   newAdmin.addActionListener(this);
	   morning.addActionListener(this);
	   evening.addActionListener(this);
	   
	   
        this.setJMenuBar(homeMenu);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        this.setVisible(true);
    }
	public void actionPerformed(ActionEvent ae){
		if(ae.getSource()==newMember){
		
		JOptionPane.showMessageDialog(this,"new member clicked");
	}
	if(ae.getSource()==newAdmin){
	JOptionPane.showMessageDialog(this,"new Admin clicked");
	}
	if(ae.getSource()==newOrg){
	JOptionPane.showMessageDialog(this,"new Organization clicked");
	}
	if(ae.getSource()==morning){
		this.setVisible(false);
		new collection();
	}
	}

    public static void main(String args[]) {
        new AdminPanel(); 
    }
}
