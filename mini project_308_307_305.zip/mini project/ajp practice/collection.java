import java.awt.*;
import javax.swing.*;

class collection extends JFrame{
  collection()
  {
   setLayout(null);
   setSize(500,400);
   setTitle("Hello to next ");
   setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   setVisible(true);
   
  }
}