package dairy.management.system;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Date;
import java.sql.*;
import Connection.DBConnection;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class Bill_Generate extends javax.swing.JFrame {

    public Bill_Generate() {
        initComponents();
        setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);
    }

    private void initComponents() {
       payable = new javax.swing.JLabel();
       payable_val=new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        reg_no = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Bill_table = new javax.swing.JTable();
        From_date = new com.toedter.calendar.JDateChooser();
        To_date = new com.toedter.calendar.JDateChooser();
        pay = new javax.swing.JButton();
        sumLabel = new javax.swing.JLabel();
        printButton = new javax.swing.JButton(); // Initialization of printButton

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        // Center-align the "Billing System" label
        jLabel1.setFont(new java.awt.Font("Segoe UI", Font.BOLD, 16));
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel1.setText("Billing System");

        jLabel2.setText("Reg No :");

        jLabel3.setText("From Date :");

        jLabel4.setText("To Date :");
        
        payable.setText("Payable :");

        // Set the preferred size of the text fields
        reg_no.setPreferredSize(new Dimension(150, 22));

        jButton1.setBackground(new java.awt.Color(255, 153, 153));
        jButton1.setText("Generate Bill");
        jButton1.addActionListener(evt -> generateBill());

        printButton.setText("Print Bill"); // Set the text for the printButton
        printButton.addActionListener(evt -> printBill());
        
        Bill_table.setModel(new DefaultTableModel(
            new Object[][]{},
            new String[]{"Register Number", "Name", "Date", "Time", "Animal Type", "Fat", "SNF", "Quantity", "Rate", "Total"}
        ));
        jScrollPane1.setViewportView(Bill_table);

        pay.setText("Pay");

        sumLabel.setFont(new java.awt.Font("Segoe UI", Font.BOLD, 12));
        sumLabel.setText("Sum of Total: 0.00");
        
        payable_val.setFont(new java.awt.Font("Segoe UI", Font.BOLD, 12));
        payable_val.setText("0.0");
        
        payable.setBounds(20,340,100,30);
        payable_val.setBounds(100,340,100,30);
        add(payable);
        add(payable_val);

        // Layout adjustments
        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 850, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(256, 256, 256)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(reg_no, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel3)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(From_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(To_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(350, 350, 350)
                                    .addComponent(sumLabel))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(354, 354, 354)
                                    .addComponent(pay))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(311, 311, 311)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(printButton, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE) // Add Print button in horizontal layout
                    .addGap(351, 351, 351))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel1)
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(reg_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel3)
                        .addComponent(From_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4)
                        .addComponent(To_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton1)
                        .addComponent(printButton)) // Add Print button in vertical layout
                    .addGap(18, 18, 18)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(sumLabel)
                    .addGap(18, 18, 18)
                    .addComponent(pay)
                    .addContainerGap(68, Short.MAX_VALUE))
        );

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(jPanel1, BorderLayout.CENTER);
        pack();
    }

    private void printBill() {
        try {
            boolean complete = Bill_table.print();
            if (complete) {
                JOptionPane.showMessageDialog(this, "Printing Complete", "Print", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Printing Cancelled", "Print", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Printing Failed: " + e.getMessage(), "Print", JOptionPane.ERROR_MESSAGE);
        }
    }
      
    
   private void generateBill() {
    PreparedStatement pst = null;
    ResultSet rst = null;
    float totalSum = 0;
    try {
        if (reg_no.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Fill the Register number ...!");
            return;
        } else if (To_date.getDate() == null || From_date.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Choose dates ...!");
            return;
        }

        Date date1 = From_date.getDate();
        Date date2 = To_date.getDate();

        LocalDate startDate = date1.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate endDate = date2.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

        if (startDate.isAfter(endDate)) {
            JOptionPane.showMessageDialog(this, "From Date should not be later than To Date.");
            return;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        int reg = Integer.parseInt(reg_no.getText());
        DBConnection d = new DBConnection();
        d.conn_open();

       
        String get_name = "SELECT `Member name` FROM member_reg WHERE `Register Number` = ?";
        pst = d.getconnection().prepareStatement(get_name);
        pst.setInt(1, reg);
        rst = pst.executeQuery();

        String memberName = null;
        if (rst.next()) {
            memberName = rst.getString("Member name");
        } else {
            JOptionPane.showMessageDialog(this, "Member not found...!");
            return;
        }

        DefaultTableModel model = (DefaultTableModel) Bill_table.getModel();
        model.setRowCount(0);

        // Loop through each date between startDate and endDate
        LocalDate currentDate = startDate;
        while (!currentDate.isAfter(endDate)) {
            String query = "SELECT * FROM daily_collection1 WHERE `Register number` = ? AND Date = ?";
            pst = d.getconnection().prepareStatement(query);
            pst.setInt(1, reg);
            
            // Convert LocalDate to java.sql.Date
            java.sql.Date sqlDate = java.sql.Date.valueOf(currentDate);
            pst.setDate(2, sqlDate);

            rst = pst.executeQuery();

            // Add rows to the table for each entry found
            while (rst.next()) {
                float total = rst.getFloat("Total_Amount");
                totalSum += total; // Add to the total sum

                model.addRow(new Object[]{
                        reg,
                        memberName,
                        currentDate.format(formatter),
                        rst.getString("Time"),
                        rst.getString("Animal Type"),
                        rst.getFloat("FAT"),
                        rst.getFloat("SNF"),
                        rst.getFloat("Quantity"),
                        rst.getFloat("Rate"),
                        rst.getFloat("Total_Amount")
                });
            }
            currentDate = currentDate.plusDays(1);
        }

        
        sumLabel.setText("Sum of Total: " + totalSum);
 d.conn_close();
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "An error occurred while generating the bill. Please try again.");
    } finally {
        try {
            if (rst != null) rst.close();
            if (pst != null) pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new Bill_Generate().setVisible(true));
    }

                    
    private javax.swing.JTable Bill_table;
    private com.toedter.calendar.JDateChooser From_date;
    private com.toedter.calendar.JDateChooser To_date;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton pay;
    private javax.swing.JTextField reg_no;
    private javax.swing.JLabel sumLabel;
    private javax.swing.JLabel payable;
    private javax.swing.JButton printButton; 
      private javax.swing.JLabel payable_val;
                    
}
