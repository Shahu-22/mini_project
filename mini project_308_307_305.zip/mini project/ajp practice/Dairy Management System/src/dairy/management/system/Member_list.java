import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Vector;

public class Member_list {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/your_database_name";
    private static final String DB_USER = "your_username";
    private static final String DB_PASSWORD = "your_password";

    public static void main(String[] args) {
        JFrame frame = new JFrame("Member Register Table");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        // Column names for the JTable
        String[] columnNames = {"Register Number", "Name", "Mobile Number", "Aadhar Number"};

        // Create a table model with data from the database
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(tableModel);

        // Fetch data from the Member_register table and populate the JTable
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement statement = connection.createStatement()) {

            String query = "SELECT `Register number`, `Member name`, `Mobile number`, `Account number` FROM member_reg";
            ResultSet resultSet = statement.executeQuery(query);

            // Loop through the ResultSet and add rows to the table model
            while (resultSet.next()) {
                Vector<Object> row = new Vector<>();
                row.add(resultSet.getString("Register number"));
                row.add(resultSet.getString("Member name"));
                row.add(resultSet.getString("Mobile number"));
                row.add(resultSet.getString("Account number"));
                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error fetching data from database", "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Add the JTable to a JScrollPane and add it to the frame
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane);

        // Display the frame
        frame.setVisible(true);
    }
}
