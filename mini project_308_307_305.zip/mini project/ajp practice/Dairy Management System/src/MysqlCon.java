import java.sql.*;

class MysqlCon {
    
    public static void conn() {
        Connection con = null;
        PreparedStatement pst = null; // Changed to PreparedStatement
        ResultSet rs = null;

        try {
            // Load MySQL JDBC Driver (use the modern class name)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection to the database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dairymanagementsystem", "root", "");
            System.out.println("SUCCESSFUL CONNECTION!");

            // Prepare the SQL statement
            String query = "INSERT INTO member_register(`Member name`, `Register Number`, `Mobile Number`, `Account Number`) VALUES (?, ?, ?, ?)";
            pst = con.prepareStatement(query);

            // Set parameters for the prepared statement
            // Replace the following sample values with actual values as needed
            pst.setString(1, "John Doe"); // Example member name
            pst.setInt(2, 12345); // Example register number
            pst.setInt(3, 987654321); // Example mobile number
            pst.setInt(4, 54321); // Example account number

            // Execute the insert command
            int rowsInserted = pst.executeUpdate();
            System.out.println(rowsInserted + " row(s) inserted.");

        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found. Include it in your library path.");
        } catch (SQLException e) {
            System.out.println("SQL Error: " + e.getMessage());
        } finally {
            try {
                // Close resources to avoid memory leaks
                if (rs != null) rs.close();
                if (pst != null) pst.close(); // Close PreparedStatement
                if (con != null) con.close();
            } catch (SQLException e) {
                System.out.println("Error closing resources: " + e.getMessage());
            }
        }
    }
    
    public static void main(String args[]) {
        conn();
    }
}
