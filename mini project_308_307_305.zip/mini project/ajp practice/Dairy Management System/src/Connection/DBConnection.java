package Connection;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * DBConnection class for managing database connections and dynamic insertions.
 */
public class DBConnection {
    // Database connection details
    String DB_URL = "jdbc:mysql://localhost:3306/dairymanagementsystem";
    String USER = "root";
    String PASSWORD = "";

    // Connection objects
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
   
    // Method to open a database connection
    public void conn_open() throws SQLException {
        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish connection
            con = DriverManager.getConnection(DB_URL, USER, PASSWORD);
            System.out.println("Connection Successful");
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found. Include it in your library path.");
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage());
            throw e; // Rethrow to handle outside if needed
        }
    }
    public Connection getconnection(){
        return con;
    }

    // Method to insert data into the database dynamically
    public void Insert(String query, Object... params) {
        try {
            
            pst = con.prepareStatement(query);

          
            for (int i = 0; i < params.length; i++) {
                if (params[i] instanceof String) {
                    pst.setString(i + 1, (String) params[i]);
                } else if (params[i] instanceof Integer) {
                    pst.setInt(i + 1, (Integer) params[i]);
                } else if (params[i] instanceof Double) {
                    pst.setDouble(i + 1, (Double) params[i]);
                }else if (params[i] instanceof java.sql.Date) {
                    pst.setDate(i + 1, (java.sql.Date) params[i]);
                }  else if (params[i] instanceof Boolean) {
                    pst.setBoolean(i + 1, (Boolean) params[i]);
                } else {
                    pst.setObject(i + 1, params[i]); // Handle other types
                }
            }

          
            int rowsInserted = pst.executeUpdate();
            System.out.println(rowsInserted + " row(s) inserted.");
        } catch (SQLException e) {
            System.out.println("Error while inserting: " + e.getMessage());
        } finally {
            // Close PreparedStatement to prevent resource leaks
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (SQLException e) {
                System.out.println("Error while closing PreparedStatement: " + e.getMessage());
            }
        }
    }
    public void conn_close() {
        try {
            if (con != null) {
                con.close();
                System.out.println("Connection closed successfully.");
            }
        } catch (SQLException e) {
            System.out.println("Error while closing the connection: " + e.getMessage());
        } finally {
            con = null;
        }
    }

   
    /*public static void main(String[] args) {
        DBConnection d = new DBConnection();
        try {
            // Open the connection
            d.conn_open();
            java.sql.Date date = java.sql.Date.valueOf("2024-10-03"); 
           
            
             String query = "INSERT INTO Daily_Collection(`Register Number`, `Date`, `Time`, `Animal Type`, `FAT`, `SNF`, `Quantity`, `Rate`, `Total Amount`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            d.Insert(query,1,date,"Morning","Cow",4.5,8.2,5.0,30.0,150.0);

        } catch (SQLException ex) {
            Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, "Error while opening connection", ex);
        } finally {
           
            d.conn_close();
        }
    }*/

    public Object getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
