import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class AdminLogin extends JFrame implements ActionListener{
   JLabel username,password;
   JButton submit;
   JTextField userid,pass;
   AdminLogin(){
	   
	   JLabel title = new JLabel("Admin Login", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 24)); // Set font style, size
        title.setForeground(Color.WHITE); // Set text color
        title.setBounds(50, 20, 300, 40); // Set position and size
	   
    username=new JLabel("UserName :");
	password=new JLabel("Password :");
	userid=new JTextField();
	pass=new JTextField();
	submit=new JButton("Submit");
	username.setBounds(60,70,100,20);
	userid.setBounds(160,70,100,20);
	password.setBounds(60,110,100,20);
	pass.setBounds(160,110,100,20);
	submit.setBounds(120,150,100,30);
	//submit.setBorderRedius("5");
	add(title);
	add(username);
	add(password);
	add(userid);
	add(pass);
	add(submit);
	setSize(500,500);
	setLayout(null);
	getContentPane().setBackground(Color.blue);
	setVisible(true);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	submit.addActionListener(this);
   }
   public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == submit) {
            // Check credentials
            String usernameInput = userid.getText();
            String passwordInput = new String(pass.getText());// char array to string

            if (usernameInput.equals("shahu") && passwordInput.equals("1234")) {
                JOptionPane.showMessageDialog(this, "Logged in...");
				new AdminPanel();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid UserID or Password");
            }
        }
   }
   public static void main(String args[]){
	   new AdminLogin();
   }
}